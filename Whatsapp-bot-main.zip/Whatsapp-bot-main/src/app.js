//Importar dependencias
import express from 'express';
import config from './config/env.js';
import webhookRoutes from './routes/webhookRoutes.js';

const app = express(); //Crear app
app.use(express.json()); //Middleware

app.use('/', webhookRoutes);

app.get('/', (req, res) => {
  res.send(`<pre>Nothing to see here.
Checkout README.md to start.</pre>`);
});

// Levantar servidor
app.listen(config.PORT, () => {
  console.log(`Servidor corriendo en puerto: ${config.PORT}`);
});
