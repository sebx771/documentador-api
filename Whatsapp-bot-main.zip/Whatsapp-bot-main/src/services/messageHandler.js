//Manejar mis mensajes
import whatsappService from '../services/whatsappService.js';

class MessageHandler {
  async handleIncomingMessage(message, senderInfo) {

    console.log(message, senderInfo);

    if (message?.type === 'text') {
      const incomingMessage = message.text.body.toLowerCase().trim();

      if(this.isGreeting(incomingMessage)) {
        await this.sendWelcomeMessage(message.from, message.id, senderInfo);
        await this.sendWelcomeMenu(message.from);
      } else {
        const text = message.text.body;
        const response = `${text}`;
        await whatsappService.sendMessage(message.from, response, message.id);
      }
      await whatsappService.markAsRead(message.id);
    }
  }
  //Funcion
  isGreeting(message) {
    const greetings =["hola", "buenos dias"];
    return greetings.includes(message); //retorna un booleano
  }

  getSenderName(senderInfo) {
  const fullName = senderInfo?.profile?.name;

  if (!fullName) {
    return "Cliente bello";
  }

  const cleanName = fullName.trim();

  // Detectar si tiene letras (no solo emojis o símbolos)
  const hasLetters = /[a-zA-ZáéíóúÁÉÍÓÚñÑ]/.test(cleanName);

  if (!hasLetters) {
    return "Cliente bello";
  }

  const nameParts = cleanName.split(/\s+/);
  const firstName = nameParts[0];

  return this.capitalize(firstName);
}

  capitalize(name) {
  return name.charAt(0).toUpperCase() + name.slice(1).toLowerCase();
}

  async sendWelcomeMessage(to, messageId, senderInfo) {
    const name = this.getSenderName(senderInfo);
    const welcomeMessage = `Hola ${name}, Bienvenido a FRITOS MAYITO, un gusto atenderle! ¿En qué puedo ayudarte hoy?`;
    await whatsappService.sendMessage(to, welcomeMessage, messageId);
  }

  async sendWelcomeMenu(to) {
    const menuMessage = "Elige una opcion";
    const buttons = [
      {
        type: 'reply', reply: { id: 'option_1', title: '🥟 Ver menú' }
      },
      {
        type: 'reply', reply: { id: 'option_2', title: '🛒 Hacer pedido' }
      },
      {
        type: 'reply', reply: { id: 'option_3', title: '📍 Ubicación' }
      }
    ];

    await whatsappService.sendInteractiveButtons(to, menuMessage, buttons);
  }

}

export default new MessageHandler();