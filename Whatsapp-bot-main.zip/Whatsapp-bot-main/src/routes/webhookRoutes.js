//Rutas que envian y reciben cierta informacion que tambien estan dentro el controllador del webhook
import express from 'express';
import webhookController from '../controllers/webhookController.js';

const router = express.Router();

router.post('/webhook', webhookController.handleIncoming);
router.get('/webhook', webhookController.verifyWebhook);

export default router;
