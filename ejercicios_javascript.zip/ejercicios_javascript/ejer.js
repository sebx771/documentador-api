const prompt = require('prompt-sync')();

console.log("=== Calculadora de Área y Perímetro ===");
console.log("1. Triángulo");
console.log("2. Rectángulo");
console.log("3. Cuadrado");
console.log("4. Círculo");

const figura = prompt("Seleccione una figura (1-4): ");
const operacion = prompt("¿Desea calcular área o perímetro? (a/p): ");
if (operacion !== "a" && operacion !== "p") {
  console.log("Opción inválida. Debe ingresar 'a' para área o 'p' para perímetro.");
  process.exit(); 
}


switch (figura) {
  case "1": 
    if (operacion === "a") {
      const base = parseFloat(prompt("Ingrese la base: "));
      const altura = parseFloat(prompt("Ingrese la altura: "));
      const area = (base * altura) / 2;
      console.log(`Área del triángulo: ${area.toFixed(2)}`);
    } else if (operacion === "p") {
      const a = parseFloat(prompt("Ingrese el lado a: "));
      const b = parseFloat(prompt("Ingrese el lado b (base): "));
      const c = parseFloat(prompt("Ingrese el lado c: "));
      const perimetro = a + b + c;
      console.log(`Perímetro del triángulo: ${perimetro.toFixed(2)}`);
    } else {
      console.log("Opción inválida (debe ser 'a' o 'p')");
    }
    break;

  case "2": 
    const baseR = parseFloat(prompt("Ingrese la base: "));
    const alturaR = parseFloat(prompt("Ingrese la altura: "));
    if (operacion === "a") {
      const area = baseR * alturaR;
      console.log(`Área del rectángulo: ${area.toFixed(2)}`);
    } else if (operacion === "p") {
      const perimetro = 2 * (baseR + alturaR);
      console.log(`Perímetro del rectángulo: ${perimetro.toFixed(2)}`);
    } else {
      console.log("Opción inválida (debe ser 'a' o 'p')");
    }
    break;

  case "3":
    const lado = parseFloat(prompt("Ingrese el lado: "));
    if (operacion === "a") {
      const area = lado * lado;
      console.log(`Área del cuadrado: ${area.toFixed(2)}`);
    } else if (operacion === "p") {
      const perimetro = 4 * lado;
      console.log(`Perímetro del cuadrado: ${perimetro.toFixed(2)}`);
    } else {
      console.log("Opción inválida (debe ser 'a' o 'p')");
    }
    break;

  case "4": 
    const radio = parseFloat(prompt("Ingrese el radio: "));
    if (operacion === "a") {
      const area = Math.PI * radio * radio;
      console.log(`Área del círculo: ${area.toFixed(2)}`);
    } else if (operacion === "p") {
      const perimetro = 2 * Math.PI * radio;
      console.log(`Perímetro del círculo: ${perimetro.toFixed(2)}`);
    } else {
      console.log("Opción inválida (debe ser 'a' o 'p')");
    }
    break;

  default:
    console.log("Figura inválida (debe ser 1-4)");
}
