const prompt = require('prompt-sync')();

function leerVector(nombre) {
  const vector = [];
  console.log(`\nIngrese 5 números ordenados ascendentemente para el vector ${nombre}:`);

  for (let i = 0; i < 5; i++) {
    let numero;

    while (true) {
      numero = parseInt(prompt(`Elemento [${i + 1}]: `));

      if (isNaN(numero)) {
        console.log("Debe ingresar un número válido.");
      } else if (i > 0 && numero < vector[i - 1]) {
        console.log("Error: el número debe ser mayor o igual al anterior.");
      } else {
        vector.push(numero);
        break;
      }
    }
  }

  return vector;
}

const vector1 = leerVector("A");
const vector2 = leerVector("B");

const combinado = vector1.concat(vector2);
combinado.sort((a, b) => a - b);

console.log("\n=== Resultado ===");
console.log("Vector combinado y ordenado:");
console.log(combinado.join(" "));
  