const prompt = require('prompt-sync')();

const personas = [];
let opcion;

do {
  console.log("\n=== MENÚ ===");
  console.log("a. Agregar persona");
  console.log("b. Mostrar información por posición");
  console.log("s. Salir");

  opcion = prompt("Seleccione una opción: ").toLowerCase();

  switch (opcion) {
    case 'a':
      if (personas.length >= 6) {
        console.log("Ya se han registrado las 6 personas permitidas.");
        break;
      }

      console.log("\n--- Registro de Persona ---");

      
      const nombre = prompt("Nombre: ");

      let cedula;
      while (true) {
        cedula = prompt("Cédula: ");
        if (!isNaN(cedula) && cedula.trim() !== "") break;
        console.log("Cédula inválida.");
      }

      const fechaNacimiento = prompt("Fecha de nacimiento (dd/mm/aaaa): ");

      let correo;
      while (true) {
        correo = prompt("Correo electrónico: ");
        if (correo.includes("@") && correo.includes(".")) break;
        console.log("Correo inválido.");
      }

      const ciudadResidencia = prompt("Ciudad de residencia: ");
      const ciudadOrigen = prompt("Ciudad de origen: ");

      
      const canciones = [];
      console.log("\n--- Canciones favoritas ---");

      for (let i = 0; i < 3; i++) {
        console.log(`\nCanción ${i + 1}:`);
        const titulo = prompt("Título: ");
        const artista = prompt("Artista: ");
        canciones.push({ titulo, artista });

        if (i < 2) {
          const continuar = prompt("¿Desea ingresar otra canción? (s/n): ").toLowerCase();
          if (continuar !== "s") break;
        }
      }

      
      const persona = {
        nombre,
        cedula,
        fechaNacimiento,
        correo,
        ciudadResidencia,
        ciudadOrigen,
        canciones
      };

      personas.push(persona);
      console.log("¡Persona registrada exitosamente!");
      break;

    case 'b':
      if (personas.length === 0) {
        console.log("Aún no hay personas registradas.");
        break;
      }

      let pos;

      while (true) {
        pos = parseInt(prompt(`Ingrese la posición (0 a ${personas.length - 1}): `));
        if (!isNaN(pos) && pos >= 0 && pos < personas.length) {
          break;
        } else {
          console.log("Posición inválida. Intente nuevamente.");
        }
      }

      const p = personas[pos];

      console.log(`\n--- Información de la persona en posición ${pos} ---`);
      console.log(`Nombre: ${p.nombre}`);
      console.log(`Cédula: ${p.cedula}`);
      console.log(`Fecha de nacimiento: ${p.fechaNacimiento}`);
      console.log(`Correo: ${p.correo}`);
      console.log(`Ciudad de residencia: ${p.ciudadResidencia}`);
      console.log(`Ciudad de origen: ${p.ciudadOrigen}`);

      console.log("\nCanciones favoritas:");
      p.canciones.forEach((cancion, i) => {
        console.log(`  ${i + 1}. "${cancion.titulo}" - ${cancion.artista}`);
      });
      break;

    case 's':
      console.log("Saliendo del programa...");
      break;

    default:
      console.log("Opción inválida. Intente nuevamente.");
  }

} while (opcion !== 's');
