const prompt = require('prompt-sync')();

const edades = [];

console.log("=== Registro de Edades ===");

for (let i = 0; i < 10; i++) {
  let edad;

  while (true) {
    edad = parseInt(prompt(`Ingrese la edad de la persona #${i + 1}: `));

    if (edad >= 1 && edad <= 120) {
      edades.push(edad);
      break;
    } else {
      console.log("Edad inválida. Debe estar entre 1 y 120 años.");
    }
  }
}


let menores = 0;
let mayores = 0;
let adultosMayores = 0;
let suma = 0;
let edadMinima = edades[0];
let edadMaxima = edades[0];

for (let i = 0; i < edades.length; i++) {
  const edad = edades[i];

  if (edad < 18) {
    menores++;
  } else {
    mayores++;
    if (edad >= 60) {
      adultosMayores++;
    }
  }

  suma += edad;

  if (edad < edadMinima) edadMinima = edad;
  if (edad > edadMaxima) edadMaxima = edad;
}

const promedio = suma / edades.length;


console.log("\n=== Resultados ===");
console.log(`Menores de edad: ${menores}`);
console.log(`Mayores de edad: ${mayores}`);
console.log(`Adultos mayores (>= 60 años): ${adultosMayores}`);
console.log(`Edad más baja: ${edadMinima}`);
console.log(`Edad más alta: ${edadMaxima}`);
console.log(`Promedio de edades: ${promedio.toFixed(2)}`);
